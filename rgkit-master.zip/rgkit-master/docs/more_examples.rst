More examples
=============

Checking if there's a robot at a location

Since game.robots is a dictionary of robots with locations as keys and
robots as values, you can use: ``(x, y) in game.robots``

which is True if there's a robot at ``(x, y)`` and ``False`` otherwise.
