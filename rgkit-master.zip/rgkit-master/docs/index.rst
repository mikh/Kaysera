.. rgkit documentation master file, created by
   sphinx-quickstart on Thu Mar 27 19:28:30 2014.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to rgkit's documentation!
=================================

Contents:

.. toctree::
   :maxdepth: 2

   game_rules
   getting_started
   library
   more_examples
   rgkit
   security


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`


