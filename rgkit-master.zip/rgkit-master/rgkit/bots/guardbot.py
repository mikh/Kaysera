class Robot:
    def act(self, game):
        return ['guard']
